/* Calendário brasileiro da Missa. O mesmo módulo roda no navegador e no Node.
 * A escolha do dia só usa regras, o Próprio dos Santos e o cômputo gregoriano.
 * O catálogo das leituras é consultado depois, pela chave litúrgica obtida. */
"use strict";
(() => {
  if (typeof module !== "undefined" && module.exports) {
    require("./santoral.js");
    require("./facultativas.js");
  }
  const santos = globalThis.SANTORAL_BR;
  const MS = 86400000;
  const semana = ["Domingo", "Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado"];
  const meses = ["janeiro","fevereiro","março","abril","maio","junho","julho","agosto","setembro","outubro","novembro","dezembro"];
  const positivo = (x, n) => ((x % n) + n) % n;
  const wd = n => positivo(n + 4, 7); // 1970-01-01 foi quinta-feira.
  const proxDomingo = n => n + positivo(-wd(n), 7);
  const pad = (n, width = 2) => String(n).padStart(width, "0");
  const iso = n => new Date(n * MS).toISOString().slice(0, 10);
  function diaCivil(y,m,d) {
    const data = new Date(0);
    data.setUTCFullYear(y, m - 1, d);
    return data.getTime() / MS;
  }
  function numeroData(s) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(s) || s.startsWith("0000")) throw Error("Use uma data entre 0001-01-01 e 9999-12-31.");
    const n = diaCivil(+s.slice(0,4),+s.slice(5,7),+s.slice(8));
    if (iso(n) !== s) throw Error("Data civil inválida.");
    return n;
  }
  function pascoa(y) {
    const div = Math.floor;
    const a=y%19, b=div(y/100), c=y%100;
    const h=positivo(19*a+b-div(b/4)-div((b-div((b+8)/25)+1)/3)+15,30);
    const l=positivo(32+2*(b%4)+2*div(c/4)-h-c%4,7);
    const t=h+l-7*div((a+11*h+22*l)/451)+114;
    return diaCivil(y, div(t/31), t%31+1);
  }

  const TC="Tempo Comum", ADV="Tempo do Advento", NAT="Tempo do Natal", QUA="Tempo da Quaresma", PAS="Tempo da Páscoa", SS="Semana Santa";
  const nomes = {
    epifania:"Epifania do Senhor", batismo:"Batismo do Senhor", familia:"Sagrada Família de Jesus, Maria e José",
    cinzas:"QUARTA-FEIRA DE CINZAS", ramos:"DOMINGO DE RAMOS DA PAIXÃO DO SENHOR",
    paixao:"PAIXÃO DO SENHOR", vigilia:"SÁBADO SANTO", pascoa:"DOMINGO DA PÁSCOA NA RESSURREIÇÃO DO SENHOR",
    misericordia:"DOMINGO NA OITAVA DA PÁSCOADomingo da Divina Misericórdia", ascensao:"Ascensão do Senhor",
    pentecostes:"Domingo de Pentecostes", mae:"Bem-aventurada Virgem Maria, Mãe da Igreja",
    trindade:"Santíssima Trindade", corpus:"Santíssimo Corpo e Sangue de Cristo", coracao:"Sagrado Coração de Jesus",
    imaculado:"Imaculado Coração da Bem-aventurada Virgem Maria", rei:"Nosso Senhor Jesus Cristo, Rei do Universo",
    pedro:"Santos Pedro e Paulo Apóstolos", assuncao:"Assunção da Bem-aventurada Virgem Maria", todos:"Todos os Santos"
  };
  function marcos(y) {
    const em = (m,d) => diaCivil(y,m,d);
    const p=pascoa(y), advento=proxDomingo(em(11,27)), epifania=proxDomingo(em(1,2));
    const batismo=epifania + (epifania>=em(1,7) ? 1 : 7);
    const anuncio=em(3,25), jose=em(3,19), joao=em(6,24);
    const anOrd = wd(anuncio)===0 ? anuncio+1 : anuncio;
    const santosNov=proxDomingo(em(11,1));
    return {
      p,advento,epifania,batismo,segundo:proxDomingo(batismo+1),natal:em(12,25),
      familia:wd(em(12,25))===0 ? em(12,30) : proxDomingo(em(12,26)),
      pedro:proxDomingo(em(6,28)), assuncao:proxDomingo(em(8,15)),
      todos:santosNov===em(11,2) ? em(11,1) : santosNov,
      jose:jose>=p-7 && jose<=p+7 ? p-8 : jose-(wd(jose)===0 ? 1 : 0),
      anuncio:anuncio>=p-7 && anuncio<=p+7 ? p+8 : anOrd,
      joao:(joao===p+68 || joao===p+60) ? joao-1 : joao
    };
  }
  const marcosPorAno = new Map();
  function ano(y) {
    if (!marcosPorAno.has(y)) marcosPorAno.set(y,marcos(y));
    return marcosPorAno.get(y);
  }

  function calendario(data, transferenciaJoao=23) {
    const n=numeroData(data), y=Number(data.slice(0,4)), m=Number(data.slice(5,7)), dia=Number(data.slice(8));
    const w=wd(n), mmdd=data.slice(5), a=ano(y), delta=n-a.p;
    const anoLiturgico=y+Number(n>=a.advento);
    const dominical="CAB"[anoLiturgico%3];
    const ferial=anoLiturgico%2 ? "I" : "II";
    function evento(nome,chave,tempo,cor,ordem,grau="",ciclo="") {
      return {nome,chave,tempo,cor,ordem,grau,ciclo};
    }
    function especial(id,tempo,cor,ordem,grau="",porCiclo=false) {
      return evento(nomes[id],id+(porCiclo?"/"+dominical:""),tempo,cor,ordem,grau,
                    grau==="Memória" || id==="cinzas" ? "" : dominical);
    }
    function periodo(num,sufixo,tempo,cor,chave,ordem) {
      const nome=num+(w===0?"º Domingo ":"ª Semana ")+sufixo;
      return evento(nome,chave,tempo,cor,ordem,"",w===0?dominical:"");
    }
    function ordinario() {
      const num=delta<0 ? 2+Math.floor((n-a.segundo)/7) : 34+Math.floor((n-(a.advento-7))/7);
      const ciclo=w===0 ? dominical : ferial;
      let chave=["comum",num,w,ciclo].join("/");
      // No ano A a multiplicação dos pães já foi proclamada no domingo,
      // salvo quando o domingo foi a Transfiguração, 6 de agosto.
      if (num===18 && (w===1 || w===2)) {
        const domingo=iso(n-w).slice(5);
        chave+="/"+(dominical==="A" && domingo!=="08-06" ? "apos-multiplicacao" : "habitual");
      }
      const e=periodo(num,"do Tempo Comum",TC,"verde",chave,w===0?6:13);
      e.ciclo=ciclo;
      return e;
    }
    function temporal() {
      if (n===a.epifania) return especial("epifania",NAT,"branco",2,"Solenidade");
      if (n===a.batismo) return especial("batismo",NAT,"branco",5,"Festa",true);
      if (m===1 && n<a.batismo) {
        const antes=n<a.epifania;
        const chave=antes?"jan/"+dia:"epifania/dia/"+w;
        return evento("Tempo do Natal "+(antes?"antes":"depois")+" da Epifania",chave,NAT,"branco",13);
      }
      if (n===a.familia) return especial("familia",NAT,"branco",5,"Festa",true);
      if (n>=a.natal) return evento((dia-24)+"º Dia na Oitava de Natal","oitava-natal/"+dia,NAT,"branco",9);
      if (n>=a.advento) {
        const num=1+Math.floor((n-a.advento)/7);
        let chave="advento/"+num+"/"+w;
        if (w===0) chave+="/"+dominical+(dia===24?"/vespera":"");
        else if (m===12 && dia>=17) chave="dez/"+dia;
        else if (num===1 && w===1) chave+=dominical==="A"?"/A":"/BC";
        return periodo(num,"do Advento",ADV,w===0 && num===3?"rosa":"roxo",chave,w===0?2:dia>=17 && m===12?9:13);
      }
      if (n===a.advento-7) return especial("rei",TC,"branco",3,"Solenidade",true);
      if (delta===-46) return especial("cinzas",QUA,"roxo",2);
      if (delta>=-45 && delta<=-43) return evento("depois das Cinzas","cinzas/"+w,QUA,"roxo",9);
      if (delta>=-42 && delta<=-8) {
        const num=1+Math.floor((delta+42)/7);
        let chave="quaresma/"+num+"/"+w;
        if (w===0) chave+="/"+dominical;
        if (num===5 && w===1) chave+=dominical==="C"?"/C":"/AB";
        return periodo(num,"da Quaresma",QUA,w===0 && num===4?"rosa":"roxo",chave,w===0?2:9);
      }
      if (delta===-7) return especial("ramos",SS,"vermelho",2,"",true);
      if (delta>=-6 && delta<=-3) return evento("Semana Santa","santa/"+w,SS,delta===-3?"branco":"roxo",2);
      if (delta===-2) return especial("paixao",SS,"vermelho",1);
      if (delta===-1) return especial("vigilia",SS,"branco",1,"",true);
      if (delta===0) return especial("pascoa",PAS,"branco",1);
      if (delta>=1 && delta<=6) return evento("OITAVA DA PÁSCOA","oitava-pascoa/"+w,PAS,"branco",2);
      if (delta===7) return especial("misericordia",PAS,"branco",2,"",true);
      if (delta===42) return especial("ascensao",PAS,"branco",2,"Solenidade",true);
      if (delta===49) return especial("pentecostes",PAS,"vermelho",2,"Solenidade",true);
      if (delta>=8 && delta<49) {
        const num=1+Math.floor(delta/7);
        let chave="pascal/"+num+"/"+w;
        if (w===0) chave+="/"+dominical;
        if (num===4 && w===1) chave+=dominical==="A"?"/A":"/BC";
        return periodo(num,"da Páscoa",PAS,"branco",chave,w===0?2:13);
      }
      return ordinario();
    }
    const base=temporal();
    let diaPrincipal=base;
    function propor(e) {
      if (e.ordem < diaPrincipal.ordem) diaPrincipal=e;
    }
    const moveis = [
      [a.p+50,"mae","branco",10,"Memória",false], [a.p+56,"trindade","branco",3,"Solenidade",true],
      [a.p+60,"corpus","branco",3,"Solenidade",true], [a.p+68,"coracao","branco",3,"Solenidade",true],
      [a.p+69,"imaculado","branco",10,"Memória",false], [a.pedro,"pedro","vermelho",3,"Solenidade",false],
      [a.assuncao,"assuncao","branco",3,"Solenidade",false], [a.todos,"todos","branco",3,"Solenidade",false]
    ];
    for (const [quando,id,cor,ordem,grau,ciclo] of moveis) {
      if (n===quando) propor(especial(id,base.tempo,cor,ordem,grau,ciclo));
    }
    let fixa=mmdd;
    const corpusEmSaoJoao=a.p+60===diaCivil(y,6,24);
    const dataDeJoao=corpusEmSaoJoao && Number(transferenciaJoao)===25 ? a.joao+2 : a.joao;
    const transferiveis={"03-19":a.jose,"03-25":a.anuncio,"06-24":dataDeJoao};
    if (Object.hasOwn(transferiveis,fixa) && transferiveis[fixa]!==n) fixa="";
    for (const [chave,quando] of Object.entries(transferiveis)) if (quando===n) fixa=chave;
    const s=santos[fixa];
    if (s) {
      let ordem={solenidade:3,"festa-do-senhor":5,festa:7,memoria:10}[s.classe];
      if (fixa==="12-08" || fixa==="12-25") ordem=1;
      let chave=s.proprias ? "proprio/"+fixa : base.chave;
      if (fixa==="02-02" || fixa==="09-14" || fixa==="08-06") chave+=w===0?"/domingo":"/semana";
      if (fixa==="08-06") chave+="/"+dominical;
      propor(evento(s.nome,chave,base.tempo,s.cor,ordem,s.grau,s.classe==="memoria"?"":dominical));
    }
    const e=diaPrincipal;
    const opcoes=[];
    if (e.chave==="imaculado" && s?.classe==="memoria" && s.grau==="Memória") {
      e.grau="Memória facultativa";
      opcoes.push({modo:"Memória facultativa",nome:s.nome,chave:s.proprias?"proprio/"+fixa:base.chave,cor:s.cor});
      opcoes.push({modo:"Féria com as leituras do dia",nome:base.nome,chave:base.chave,cor:base.cor});
    } else if (e===base && (e.ordem===13 || e.ordem===9)) {
      const modo=e.ordem===9?"Comemoração facultativa (coleta)":"Memória facultativa";
      for (const nome of globalThis.FACULTATIVAS_BR[mmdd] || []) opcoes.push({modo,nome});
      if (e.ordem===9 && s?.classe==="memoria") opcoes.push({modo,nome:s.nome});
      if (e.tempo===TC && w===6) opcoes.push({modo,nome:"Santa Maria no sábado"});
    } else if (e.grau==="Memória facultativa") {
      opcoes.push({modo:"Féria com as leituras do dia",nome:base.nome,chave:base.chave,cor:base.cor});
    }
    const ferialRotulo=e.ciclo==="I"?"Ímpar (I)":e.ciclo==="II"?"Par (II)":e.ciclo;
    const joseProprio=diaCivil(y,3,19);
    // Estar no sábado antes de Ramos não basta: 19 de março pode ser esse sábado.
    const joseAntecipado=a.jose===a.p-8 && a.jose!==joseProprio && (n===a.jose || n===joseProprio);
    return {data,celebracao:e.nome,chave:e.chave,grau:e.grau,cor:e.cor,tempo_fonte:e.tempo,
      ano_liturgico:anoLiturgico,ciclo_dominical:dominical,ciclo_ferial:ferial,ciclo_fonte:ferialRotulo,opcoes_memoria:opcoes,
      transferencia_joao:corpusEmSaoJoao && delta>=59 && delta<=61?Number(transferenciaJoao):null,
      ...(joseAntecipado ? {transferencia_sao_jose:{de:iso(joseProprio),para:iso(a.jose),
        situacao:y===2008?"documentada-em-2008":"projecao",impedimento:joseProprio===a.p-7?"Domingo de Ramos":"Semana Santa"}} : {}),
      qualificacao:[e.grau,ferialRotulo?"Ano "+ferialRotulo:""].filter(Boolean).join(", "),
      contexto:e!==base && base.ordem>=6 && !base.nome.includes("Dia na Oitava")?base.nome:"",
      data_extenso:semana[w]+", "+dia+" de "+meses[m-1]+" de "+pad(y,4)};
  }
  function resolver(data,catalogo,transferenciaJoao=23,opcao=0) {
    const plano=calendario(data,transferenciaJoao);
    if (opcao) {
      const escolha=plano.opcoes_memoria[Number(opcao)-1];
      if (!escolha?.chave) throw Error("Opção sem formulário próprio catalogado para esta data.");
      const feria=escolha.modo.startsWith("Féria");
      plano.opcao_selecionada=Number(opcao);
      plano.celebracao=escolha.nome; plano.chave=escolha.chave; plano.cor=escolha.cor;
      plano.grau=feria?"":escolha.modo;
      plano.ciclo_fonte=feria?(plano.ciclo_ferial==="I"?"Ímpar (I)":"Par (II)"):"";
      plano.qualificacao=feria?"Ano "+plano.ciclo_fonte:escolha.modo;
      if (feria) plano.contexto="";
    }
    const fonte=catalogo.chaves[plano.chave];
    if (!fonte) throw Error("Formulário ausente do catálogo: "+plano.chave);
    const avisos=[];
    if (fonte.missas_noturnas) avisos.push("As missas da Vigília e da Noite vêm de outro 24 de dezembro. O Natal tem as mesmas leituras noturnas nos três ciclos.");
    const a=ano(Number(data.slice(0,4))), n=numeroData(data);
    if (plano.chave==="epifania/dia/1" && data.endsWith("-01-03"))
      avisos.push("A Epifania foi celebrada ontem. Aplicam-se as leituras da segunda-feira depois da Epifania.");
    if (plano.transferencia_sao_jose) {
      const t=plano.transferencia_sao_jose, sabado=Number(t.para.slice(8))+" de março";
      avisos.push("São José: 19 de março coincide com "+(t.impedimento==="Semana Santa"?"a Semana Santa":"o Domingo de Ramos")+". "+
        (t.situacao==="documentada-em-2008" ? "Em 2008 a Santa Sé determinou a celebração no sábado, "+sabado+" (Notitiae, 2006, p. 96)."
         : "O sábado antes de Ramos, "+sabado+", é o dia livre mais próximo na tabela do Missal (nn. 59–60). A transferência é uma projeção; confirme-a no Diretório da CNBB de "+data.slice(0,4)+"."));
    }
    if (plano.chave==="proprio/05-14" && n===a.p+50) avisos.push("A festa de São Matias precede a memória de Maria, Mãe da Igreja, nesta segunda-feira depois de Pentecostes.");
    if (plano.transferencia_joao) avisos.push("Corpus Christi coincide com 24 de junho. Transferência provisória da Natividade de São João Batista para "+plano.transferencia_joao+" de junho. Os dias 23 e 25 estão livres. A escolha final cabe ao Diretório anual.");
    const textos_externos={};
    for (const id of [fonte.formulario,fonte.missas_noturnas?.formulario]) {
      if (id && catalogo.textos_externos[id]) textos_externos[id]=catalogo.textos_externos[id];
    }
    return {...plano,origem:"calculada",edicao:catalogo.edicao,formulario:fonte.formulario,
      testemunho:fonte.testemunho,sha256_testemunho:fonte.sha256_testemunho,
      fonte:"https://api-liturgia.edicoescnbb.com.br/contents/in/date/"+fonte.testemunho,
      rotulo_referencias:fonte.rotulo,referencias:{detalhes:fonte.referencias,resumo:fonte.referencias},
      referencias_testemunho:{detalhes:fonte.cabecalho_testemunho,resumo:fonte.resumo??fonte.cabecalho_testemunho},
      complemento_de:fonte.complemento_de,missas_noturnas:fonte.missas_noturnas,textos_externos,avisos};
  }
  const api={calendario,resolver,numeroData,iso,pascoa};
  globalThis.LiturgiaBR=api;
  if (typeof module!=="undefined" && module.exports) module.exports=api;
})();
