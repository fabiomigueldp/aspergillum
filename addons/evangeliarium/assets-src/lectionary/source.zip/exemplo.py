"""Integração: importe leituras(data) para receber um dicionário Python."""
import json
from pathlib import Path
import subprocess
import sys

def leituras(data):
    processo = subprocess.run(
        [sys.executable, str(Path(__file__).with_name("liturgia.py")), "dia", data, "--json"],
        check=True, capture_output=True, text=True, encoding="utf-8",
    )
    return json.loads(processo.stdout)

if __name__ == "__main__":
    print(json.dumps(leituras(sys.argv[1] if len(sys.argv) > 1 else "2026-11-05"), ensure_ascii=False, indent=2))
