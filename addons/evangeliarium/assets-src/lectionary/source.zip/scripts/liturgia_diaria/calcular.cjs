"use strict";
const fs = require("node:fs");
const path = require("node:path");
const leitor = path.resolve(__dirname,"../../sources/liturgia_diaria/cnbb/leitor");
const motor = require(path.join(leitor,"motor.js"));

function inventario() {
  // Mesmo calendário civil, Páscoa e ano módulo 6 significam exatamente as
  // mesmas datas móveis e os mesmos ciclos. Guardar um ano por configuração.
  const anos = Array.from({length:9999},(_,i)=>i+1);
  const distancia = y => y<2020 ? 2019-y : y>2036 ? y-2036 : 100000;
  anos.sort((a,b)=>distancia(a)-distancia(b) || a-b);
  const classes = new Map(), testemunhos = {}, preferencia = {};
  let dias = 0;
  for (const y of anos) {
    const ano = String(y).padStart(4,"0");
    const inicio = motor.numeroData(ano+"-01-01"), fim=motor.numeroData(ano+"-12-31");
    const assinatura = [inicio%7 < 0 ? (inicio%7)+7 : inicio%7,fim-inicio,motor.pascoa(y)-inicio,y%6].join("/");
    if (classes.has(assinatura)) continue;
    classes.set(assinatura,y);
    for(let dia=inicio;dia<=fim;dia++) {
      const data=motor.iso(dia), e=motor.calendario(data);
      dias++;
      const prioridade = e.grau==="Memória" && !e.chave.startsWith("proprio/") ? 1 : 0;
      if (!(e.chave in testemunhos) || prioridade<preferencia[e.chave]) {
        testemunhos[e.chave]=data;
        preferencia[e.chave]=prioridade;
      }
    }
  }
  return {classes:classes.size,dias_representativos:dias,testemunhos};
}

const pedido = JSON.parse(fs.readFileSync(0,"utf8"));
if (pedido.inventario) {
  process.stdout.write(JSON.stringify(inventario()));
} else {
  if (pedido.resolver) require(path.join(leitor,"catalogo-motor.js"));
  const resultados=pedido.datas.map(d => pedido.resolver ? motor.resolver(d,globalThis.CATALOGO_MOTOR,pedido.transferencia_joao,pedido.opcao) : motor.calendario(d,pedido.transferencia_joao));
  // A CLI já tem os corpos na biblioteca compacta; não retransmitir texto por dia.
  if (pedido.sem_textos) for (const r of resultados) delete r.textos_externos;
  process.stdout.write(JSON.stringify(resultados));
}
