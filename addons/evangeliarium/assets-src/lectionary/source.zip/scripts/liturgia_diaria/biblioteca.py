"""Biblioteca compacta de formulários: consulta sem SQLite nem arquivo de datas."""
from __future__ import annotations

import gzip
import json
from functools import lru_cache
from pathlib import Path

from fonte import ACERVO, digest
from motor import LEITOR, carregar_js

ARQUIVO = ACERVO / "motor" / "biblioteca.json.gz"
REGRAS = ("motor.js", "santoral.js", "facultativas.js", "catalogo-motor.js")
SCHEMA = "liturgia-biblioteca/v1"


def codificar(obj):
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8")




@lru_cache(maxsize=1)
def carregar():
    if not ARQUIVO.is_file():
        raise ValueError("biblioteca compacta ausente; reinstale o pacote completo da mesma edição")
    try:
        doc = json.loads(gzip.decompress(ARQUIVO.read_bytes()))
    except (OSError, EOFError, ValueError) as e:
        raise ValueError("biblioteca compacta ilegível; reinstale o pacote completo da mesma edição") from e
    if doc.get("schema") != SCHEMA:
        raise ValueError("versão desconhecida da biblioteca compacta")
    for nome in REGRAS:
        if doc["regras_sha256"].get(nome) != digest((LEITOR/nome).read_bytes()):
            raise ValueError("biblioteca e regras de edições diferentes: " + nome + "; reinstale o pacote completo da mesma edição")
    cat = carregar_js(LEITOR / "catalogo-motor.js")
    ids = {e["formulario"] for e in cat["chaves"].values()}
    ids.update(e["missas_noturnas"]["formulario"] for e in cat["chaves"].values() if e.get("missas_noturnas"))
    complementos = {e["complemento_de"] for e in cat["chaves"].values() if e.get("complemento_de")}
    if (cat["edicao"] != doc["edicao"] or ids != set(doc["formularios"])
            or complementos != set(doc["complementos"])):
        raise ValueError("biblioteca não cobre a edição instalada; reinstale o pacote completo da mesma edição")
    for fid, secs in doc["formularios"].items():
        if digest(codificar(secs)) != fid:
            raise ValueError("texto alterado na biblioteca: " + fid)
    return doc
