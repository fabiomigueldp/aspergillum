"""Ponte para o motor usado também pelo leitor, sempre sem rede."""
from __future__ import annotations

import json
from copy import deepcopy
import shutil
import subprocess
from pathlib import Path

from fonte import ACERVO

LEITOR = ACERVO / "leitor"
PONTE = Path(__file__).with_name("calcular.cjs")


def carregar_js(path):
    return json.loads(path.read_text(encoding="utf-8").split(" = ",1)[1].removesuffix(";\n"))


def executar(pedido):
    node = shutil.which("node")
    if not node:
        raise ValueError("O cálculo na linha de comando requer Node.js. O leitor abrir.html funciona diretamente no navegador.")
    proc = subprocess.run([node, str(PONTE)], input=json.dumps(pedido).encode("utf-8"),
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if proc.returncode:
        linhas = proc.stderr.decode("utf-8", errors="replace").splitlines()
        causa = next((s for s in linhas if s.startswith("Error:")), "falha ao ler as regras locais")
        raise ValueError(causa.removeprefix("Error: "))
    return json.loads(proc.stdout)


def secoes_formulario(cx, fid, extras):
    if cx is None:
        from biblioteca import carregar
        secs = carregar()["formularios"].get(fid)
        if secs is None:
            raise ValueError("Formulário ausente da biblioteca compacta: " + fid)
        return [dict(ordem=i, **deepcopy(s)) for i, s in enumerate(secs, 1)]
    if fid in extras:
        return [dict(ordem=i, tipo=s["tipo"], titulo=s["titulo"], formulario=s["formulario"],
                     relativa_a=s["relativa_a"], referencia_corpo=s["referencia_corpo"],
                     referencia_busca=s["referencia_busca"], texto=s["texto"])
                for i,s in enumerate(extras[fid],1)]
    return [dict(r) for r in cx.execute("""SELECT ordem,tipo,titulo,grupo AS formulario,relativa_a,
        referencia_corpo,referencia_busca,texto FROM secoes WHERE formulario=? ORDER BY ordem""",(fid,))]


def documento(cx, calculado):
    doc = dict(calculado)
    extras = doc.pop("textos_externos", {})
    doc["secoes"] = secoes_formulario(cx, doc["formulario"], extras)
    doc["avisos"] = list(doc.get("avisos", ()))
    doc["detalhes"] = []
    if origem := doc.get("complemento_de"):
        if cx is None:
            from biblioteca import carregar
            extra = deepcopy(carregar()["complementos"].get(origem))
            linha = (extra["descricao"], json.dumps(extra["secoes"]), json.dumps(extra["testemunhos"])) if extra else None
        else:
            linha = cx.execute("SELECT descricao,secoes,testemunhos FROM complementos WHERE data=?", (origem,)).fetchone()
        if not linha:
            raise ValueError(f"Complemento ausente do índice: {origem}")
        doc["complemento_editorial"] = {"data_testemunho":origem, "descricao":"Sobre o testemunho de "+origem+" · "+linha[0],
                                         "secoes":json.loads(linha[1]), "testemunhos":json.loads(linha[2])}
    if extra := doc.get("missas_noturnas"):
        if not doc["secoes"]:
            raise ValueError("O testemunho da missa da manhã está ausente.")
        partes = secoes_formulario(cx, extra["formulario"], extras)
        inicio = next((i for i,s in enumerate(partes)
                       if s["tipo"]=="formulario" and s["titulo"]=="Missa da Vigília"), None)
        if inicio is None:
            raise ValueError("O testemunho do Natal não contém a Missa da Vigília.")
        cab = dict(ordem=1,tipo="formulario",titulo="Missa da manhã",formulario="Missa da manhã",
                   relativa_a="",referencia_corpo="",referencia_busca="",texto="")
        for s in doc["secoes"]:
            s["formulario"]="Missa da manhã"
        doc["secoes"] = [cab, *doc["secoes"], *partes[inicio:]]
        for i,s in enumerate(doc["secoes"],1):
            s["ordem"]=i
    if not doc["secoes"] and not doc.get("complemento_editorial"):
        raise ValueError("O formulário calculado está sem texto no acervo local: "+doc["chave"])
    return doc
