"""Interface da consulta única, chamada por liturgia.py."""
from __future__ import annotations

import argparse
import calendar
from datetime import date, timedelta
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

from biblioteca import ARQUIVO, carregar
from consultas import DIAS_SEMANA, SCHEMA, TIPOS, consultar, markdown, periodo, pesquisar, simples
from motor import LEITOR, carregar_js


def data_iso(valor):
    relativos = {"hoje":0, "amanha":1, "ontem":-1}
    if simples(valor) in relativos:
        return (date.today() + timedelta(days=relativos[simples(valor)])).isoformat()
    try:
        if not re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}", valor):
            raise ValueError()
        return date.fromisoformat(valor).isoformat()
    except ValueError:
        raise argparse.ArgumentTypeError("use AAAA-MM-DD (0001 a 9999), hoje, amanhã ou ontem")


def quer_json():
    args = sys.argv[1:]
    return "--json" in args or any(v in ("json", "jsonl", "--formato=json", "--formato=jsonl") for v in args)


def erro(mensagem, codigo=1):
    obj = {"schema":"liturgia-erro/v1", "erro":mensagem, "codigo_saida":codigo}
    print(json.dumps(obj, ensure_ascii=False) if quer_json() else "Liturgia: " + mensagem, file=sys.stderr)
    return codigo


class Parser(argparse.ArgumentParser):
    def error(self, message):
        raise SystemExit(erro(message, 2))


def emitir(valor, formato="md", saida=None, *, colecao=False, render=markdown):
    """Prepara a saída inteira antes de publicar; nunca deixa um lote parcial válido."""
    if saida:
        saida = Path(saida)
        saida.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", newline="\n", suffix=".part",
                                     dir=saida.parent if saida else None, delete=False) as tmp:
        caminho = Path(tmp.name)
        try:
            itens = iter(valor) if colecao else iter([valor])
            if formato == "json" and colecao:
                tmp.write("[")
            for i, item in enumerate(itens):
                if formato == "json":
                    if colecao:
                        tmp.write(",\n" if i else "\n")
                    tmp.write(json.dumps(item, ensure_ascii=False, indent=2))
                elif formato == "jsonl":
                    tmp.write(json.dumps(item, ensure_ascii=False, separators=(",", ":")) + "\n")
                else:
                    if i:
                        tmp.write("\n\n")
                    tmp.write(render(item))
            if formato == "json" and colecao:
                tmp.write("\n]")
            if formato != "jsonl":
                tmp.write("\n")
        except BaseException:
            tmp.close()
            caminho.unlink(missing_ok=True)
            raise
    try:
        if saida:
            os.replace(caminho, saida)
        else:
            with caminho.open("r", encoding="utf-8") as f:
                shutil.copyfileobj(f, sys.stdout)
    finally:
        caminho.unlink(missing_ok=True)


def opcoes_saida(p):
    p.add_argument("--formato", choices=("md", "json", "jsonl"), default="md")
    p.add_argument("--json", dest="formato", action="store_const", const="json", help="atalho para --formato json")
    p.add_argument("--saida", type=Path, help="arquivo UTF-8; gravação atômica, cria a pasta se necessário")


def opcoes_leitura(p, *, lote=False):
    p.add_argument("--tipo", action="append", choices=TIPOS, default=[], help="repita para várias seções; inclui alternativas da seção")
    p.add_argument("--missa", help="parte do nome do formulário: crisma, ceia, vigília, aurora…")
    p.add_argument("--resumo", action="store_true", help="metadados e referências, sem o corpo dos textos")
    p.add_argument("--exigir-cnbb", action="store_true", help="falhar se o resultado depender de complemento editorial")
    if lote:
        p.add_argument("--dia-semana", action="append", type=simples, choices=DIAS_SEMANA, default=[])
        p.add_argument("--tempo", type=simples, choices=("advento", "natal", "quaresma", "semana-santa", "pascoa", "comum"))
        p.add_argument("--celebracao", help="filtrar pelo nome da celebração principal, sem distinguir caixa/acentos")
    opcoes_saida(p)


def diagnostico():
    b = carregar()
    c = carregar_js(LEITOR / "catalogo-motor.js")
    node = shutil.which("node")
    if not node:
        raise ValueError("Node.js ausente; a CLI precisa de Node.js, além de Python")
    versao = subprocess.run([node, "--version"], check=True, capture_output=True, text=True).stdout.strip()
    return {"schema":"liturgia-diagnostico/v1", "status":"ok", "edicao":b["edicao"],
            "calendario":{"inicio":"0001-01-01", "fim":"9999-12-31", "escopo":"nacional-brasil",
                          "aplicacao":"projeção das regras da edição instalada; não é reconstrução histórica"},
            "biblioteca":{"arquivo":str(ARQUIVO), "bytes":ARQUIVO.stat().st_size,
                          "chaves":len(c["chaves"]), "formularios":len(b["formularios"]),
                          "complementos_editoriais":len(b["complementos"]), "assinaturas_verificadas":True},
            "dependencias":{"python":sys.version.split()[0], "node":versao,
                            "rede":False, "sqlite":False, "arquivo_por_data":False},
            "contrato_dia":SCHEMA}


def main(argv=None):
    p = Parser(description="Liturgia brasileira offline: um calendário, textos completos e procedência explícita.",
               epilog="Guia: docs/agents/liturgia-cli.md. Evidências e aquisição: manutencao.py.")
    p.add_argument("--versao", action="version", version="liturgia-cli/v1")
    sub = p.add_subparsers(dest="acao", required=True, parser_class=Parser)
    d = sub.add_parser("dia", help="dia completo; padrão hoje, conforme o relógio local")
    d.add_argument("data", type=data_iso, nargs="?", default=date.today().isoformat())
    opcoes_leitura(d)
    d.add_argument("--opcao", type=int, help="opção litúrgica numerada que tem texto próprio disponível")
    d.add_argument("--sao-joao", type=int, choices=(23, 25), help="transferência quando 24/6 coincide com Corpus Christi")
    ds = sub.add_parser("datas", help="consultar várias datas em uma execução")
    ds.add_argument("datas", type=data_iso, nargs="+")
    opcoes_leitura(ds, lote=True)
    pe = sub.add_parser("periodo", help="textos de um intervalo inclusivo, sem lacunas silenciosas")
    pe.add_argument("inicio", type=data_iso); pe.add_argument("fim", type=data_iso)
    opcoes_leitura(pe, lote=True)
    ca = sub.add_parser("calendario", help="resumo de um mês ou ano, com referências e fontes")
    ca.add_argument("mes", help="AAAA ou AAAA-MM")
    opcoes_leitura(ca, lote=True)
    ca.set_defaults(resumo=True)
    bu = sub.add_parser("buscar", help="frase/referência na biblioteca; --de/--ate pesquisam o calendário")
    bu.add_argument("expressao")
    bu.add_argument("--de", type=data_iso); bu.add_argument("--ate", type=data_iso)
    bu.add_argument("--tipo", action="append", choices=TIPOS, default=[])
    bu.add_argument("--limite", type=int, default=20)
    opcoes_saida(bu)
    di = sub.add_parser("diagnostico", aliases=["cobertura"], help="edição, cobertura, integridade da biblioteca e dependências")
    opcoes_saida(di)
    arg = p.parse_args(argv)
    if arg.acao in ("diagnostico", "cobertura"):
        emitir(diagnostico(), arg.formato, arg.saida,
               render=lambda x: "Liturgia offline · " + x["edicao"] + "\n" +
               f"{x['biblioteca']['chaves']} chaves; {x['biblioteca']['formularios']} formulários; " +
               f"{x['biblioteca']['bytes']:,} bytes de biblioteca.\n" +
               "Datas 0001–9999, calendário nacional brasileiro. Python + Node.js. Sem rede, SQLite ou arquivo de datas.\n" +
               "Textos e regras da edição instalada; complementos e decisões provisórias são identificados.")
        return 0
    if arg.acao == "buscar":
        resultado = pesquisar(arg.expressao, inicio=arg.de, fim=arg.ate, limite=arg.limite, tipos=arg.tipo)
        def busca_md(x):
            ls = ["Busca · " + x["escopo"]]
            for r in x["resultados"]:
                ls.append(" · ".join([r.get("data", "Exemplo " + r.get("data_exemplo", "")), r["celebracao"],
                                      *(s["referencia"] for s in r["ocorrencias"])]))
                if any(s["origem_texto"] == "complemento-editorial" for s in r["ocorrencias"]):
                    ls.append("Complemento editorial identificado.")
            if not x["resultados"]:
                ls.append("Nenhum resultado.")
            if x["mais_resultados"]:
                ls.append("Há mais resultados; refine a consulta ou aumente --limite.")
            return "\n".join(ls)
        emitir(resultado, arg.formato, arg.saida, render=busca_md)
        return 0
    selecao = {"tipos":arg.tipo, "missa":arg.missa, "resumo":arg.resumo, "exigir_cnbb":arg.exigir_cnbb}
    if arg.acao == "dia":
        doc = next(consultar([arg.data], opcao=arg.opcao, sao_joao=arg.sao_joao, **selecao))
        emitir(doc, arg.formato, arg.saida)
        return 0
    selecao.update(dia_semana=arg.dia_semana, tempo=arg.tempo, celebracao=arg.celebracao)
    if arg.acao == "datas":
        datas = list(dict.fromkeys(arg.datas))
    elif arg.acao == "periodo":
        datas = periodo(arg.inicio, arg.fim)
    else:
        if not re.fullmatch(r"[0-9]{4}(?:-[0-9]{2})?", arg.mes):
            raise ValueError("calendario aceita AAAA ou AAAA-MM")
        ano = int(arg.mes[:4])
        mes = int(arg.mes[5:]) if len(arg.mes) == 7 else None
        a = date(ano, mes or 1, 1)
        b = date(ano, mes, calendar.monthrange(ano, mes)[1]) if mes else date(ano, 12, 31)
        datas = periodo(a.isoformat(), b.isoformat())
    documentos = consultar(datas, **selecao)
    if arg.acao == "calendario":
        render = lambda x: " · ".join((x["data"], x["celebracao"], x["cor"], *x["referencias_selecionadas"])) + (
            " [complemento editorial]" if x["proveniencia"]["estado_textos"] == "complemento-editorial" else "") + (
            "\n" + "\n".join(x["avisos"]) if x["avisos"] else "")
    else:
        render = markdown
    emitir(documentos, arg.formato, arg.saida, colecao=True, render=render)
    return 0


def executar_cli():
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
    try:
        return main()
    except BrokenPipeError:
        return 0
    except (OSError, ValueError, KeyError, RuntimeError, subprocess.SubprocessError) as e:
        return erro(str(e))
