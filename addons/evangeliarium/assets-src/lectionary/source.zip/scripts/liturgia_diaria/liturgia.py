"""Ponto de entrada único para consultas litúrgicas offline."""
from cli import executar_cli

if __name__ == "__main__":
    raise SystemExit(executar_cli())
