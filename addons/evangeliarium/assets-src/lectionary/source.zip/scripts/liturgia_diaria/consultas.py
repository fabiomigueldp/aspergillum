"""API de consulta única: calendário calculado e biblioteca de textos por formulário."""
from __future__ import annotations

from datetime import date
from itertools import islice
import re
import unicodedata

from biblioteca import carregar
from fonte import API, dias
from motor import documento, executar

SCHEMA = "liturgia-dia/v1"
TIPOS = ("abertura", "formulario", "divisao", "leitura_1", "leitura_2", "leitura_3",
         "leitura_4", "leitura_5", "leitura_6", "leitura_7", "epistola", "salmo",
         "aclamacao", "sequencia", "evangelho", "alternativa")
DIAS_SEMANA = ("segunda", "terca", "quarta", "quinta", "sexta", "sabado", "domingo")


def simples(s):
    return "".join(c for c in unicodedata.normalize("NFD", s.casefold()) if not unicodedata.combining(c))


def frase(s):
    return " " + " ".join(re.findall(r"[^\W_]+", simples(s))) + " "


def periodo(inicio, fim):
    a, b = date.fromisoformat(inicio), date.fromisoformat(fim)
    if a > b:
        raise ValueError("o início deve ser anterior ou igual ao fim")
    return (d.isoformat() for d in dias(a, b))


def planos(datas, *, opcao=None, sao_joao=None):
    carregar()  # Valida edição e assinaturas antes de consultar as regras.
    entradas = iter(datas)
    while lote := list(islice(entradas, 366)):
        pedido = {"datas":lote, "resolver":True, "sem_textos":True}
        if opcao is not None:
            if opcao < 1:
                raise ValueError("as opções são numeradas a partir de 1")
            pedido["opcao"] = opcao
        if sao_joao is not None:
            pedido["transferencia_joao"] = sao_joao
        for p in executar(pedido):
            yield p


def todas_secoes(doc):
    return [*doc["secoes"], *doc.get("complemento_editorial", {}).get("secoes", [])]


def preparar(plano, *, tipos=(), missa=None, resumo=False, exigir_cnbb=False, sao_joao=None):
    doc = documento(None, plano)
    # Cabeçalhos originais divergentes pertencem à auditoria, não à consulta.
    doc.pop("referencias_testemunho", None)
    doc["opcoes_memoria"] = [dict(op, numero=i, texto_disponivel=bool(op.get("chave")))
                            for i, op in enumerate(doc["opcoes_memoria"], 1)]
    if sao_joao is not None and not doc.get("transferencia_joao"):
        raise ValueError(doc["data"] + ": --sao-joao só se aplica à coincidência com Corpus Christi em 24/6")
    testemunhos = [{"id":"cnbb:" + doc["testemunho"], "data":doc["testemunho"],
                   "url":doc["fonte"], "sha256":doc["sha256_testemunho"]}]
    noturnas = doc.get("missas_noturnas")
    if noturnas:
        testemunhos.append({"id":"cnbb:" + noturnas["testemunho"], "data":noturnas["testemunho"],
                            "url":API + noturnas["testemunho"], "sha256":noturnas["sha256_testemunho"]})
    for sec in doc["secoes"]:
        origem = noturnas["testemunho"] if noturnas and sec["formulario"] != "Missa da manhã" else doc["testemunho"]
        sec["fonte_id"] = "cnbb:" + origem
    disponiveis = list(dict.fromkeys(s.get("formulario", "") for s in todas_secoes(doc) if s.get("formulario")))
    tipos_disponiveis = list(dict.fromkeys(s["tipo"] for s in todas_secoes(doc)))
    if missa:
        nomes = [n for n in disponiveis if simples(missa) in simples(n)]
        if len(nomes) != 1:
            raise ValueError(doc["data"] + ": especifique uma das missas: " + (", ".join(disponiveis) or "formulário único"))
        doc["missa_selecionada"] = nomes[0]
        doc["secoes"] = [s for s in doc["secoes"] if s["formulario"] == nomes[0]]
        if doc.get("complemento_editorial"):
            doc["complemento_editorial"]["secoes"] = [
                s for s in doc["complemento_editorial"]["secoes"] if s.get("formulario") == nomes[0]]
    if tipos:
        def aceito(s):
            return s["tipo"] in tipos or s.get("relativa_a") in tipos
        doc["secoes"] = [s for s in doc["secoes"] if aceito(s)]
        if doc.get("complemento_editorial"):
            doc["complemento_editorial"]["secoes"] = [s for s in doc["complemento_editorial"]["secoes"] if aceito(s)]
    if not todas_secoes(doc):
        raise ValueError(doc["data"] + ": nenhuma seção corresponde à seleção; disponíveis: " + ", ".join(tipos_disponiveis))
    complemento = bool(doc.get("complemento_editorial", {}).get("secoes"))
    if exigir_cnbb and complemento:
        raise ValueError(doc["data"] + ": depende de complemento editorial; --exigir-cnbb recusa essa composição")
    estado = "complemento-editorial" if complemento else "cnbb"
    usadas = {s["fonte_id"] for s in doc["secoes"]}
    doc["schema"] = SCHEMA
    doc["texto_incluido"] = not resumo
    doc["proveniencia"] = {
        "calendario":"calculado", "escopo":"nacional-brasil", "edicao":doc["edicao"],
        "publicacao_da_data":False, "estado_textos":estado,
        "fontes_cnbb":[t for t in testemunhos if t["id"] in usadas],
    }
    doc["selecao"] = {"tipos":list(tipos), "missa":doc.get("missa_selecionada"),
                      "formularios_disponiveis":disponiveis, "tipos_disponiveis":tipos_disponiveis}
    doc["referencias_selecionadas"] = list(dict.fromkeys(
        s["referencia_busca"] for s in todas_secoes(doc) if s.get("referencia_busca")))
    if resumo:
        for s in todas_secoes(doc):
            s.pop("texto", None)
    return doc


def consultar(datas, *, tipos=(), missa=None, resumo=False, exigir_cnbb=False,
              dia_semana=(), tempo=None, celebracao=None, opcao=None, sao_joao=None):
    if any(t not in TIPOS for t in tipos):
        raise ValueError("tipo de seção desconhecido; consulte dia --help")
    if any(d not in DIAS_SEMANA for d in dia_semana):
        raise ValueError("dia da semana inválido")
    if dia_semana:
        datas = (d for d in datas if DIAS_SEMANA[date.fromisoformat(d).weekday()] in dia_semana)
    for plano in planos(datas, opcao=opcao, sao_joao=sao_joao):
        if tempo and simples(tempo).replace("-", " ") not in simples(plano["tempo_fonte"]):
            continue
        if celebracao and simples(celebracao) not in simples(plano["celebracao"]):
            continue
        yield preparar(plano, tipos=tipos, missa=missa, resumo=resumo,
                       exigir_cnbb=exigir_cnbb, sao_joao=sao_joao)


def markdown(doc):
    ls = ["# " + doc["celebracao"], doc["data_extenso"] + " · " + doc["cor"]]
    ls.extend(v for v in (doc["qualificacao"], doc["contexto"], doc["tempo_fonte"]) if v)
    ls.append("Calendário nacional calculado · " + doc["edicao"] + ".")
    ls.extend(doc["avisos"])
    ls.extend(op["modo"] + " · " + op["nome"] + (f" (--opcao {i})" if op.get("chave") else "")
              for i, op in enumerate(doc["opcoes_memoria"], 1))
    if doc.get("missa_selecionada"):
        ls.append("Missa selecionada: " + doc["missa_selecionada"])
    ls.append("Passagens selecionadas · " + " · ".join(doc["referencias_selecionadas"]))
    if not doc["texto_incluido"]:
        ls.append("Resumo: os textos integrais não estão incluídos nesta saída.")
    else:
        for s in doc["secoes"]:
            if s["titulo"]:
                ls.append(("## " if s["tipo"] == "formulario" else "### ") + s["titulo"])
            if s["texto"]:
                ls.append(s["texto"].replace("\n", "  \n"))
    if extra := doc.get("complemento_editorial"):
        ls.extend(["## Complemento editorial", extra["descricao"]])
        for s in extra["secoes"]:
            ls.extend(["### " + s["titulo"], s["referencia_busca"]])
            if doc["texto_incluido"]:
                ls.append(s["texto"].replace("\n", "  \n"))
            ls.append("Fonte: " + s.get("fonte", "Edições CNBB") + " · " +
                      (s.get("data_origem") or "p. " + str(s.get("pagina_pdf", ""))) + ".")
    for t in doc["proveniencia"]["fontes_cnbb"]:
        ls.append(f"Testemunho das Edições CNBB · {t['data']} · SHA-256 {t['sha256']}.")
    return "\n\n".join(ls)


def pesquisar(expressao, *, inicio=None, fim=None, limite=20, tipos=()):
    """Sem período, busca os formulários; com período, busca o calendário calculado."""
    from motor import LEITOR, carregar_js

    consulta = frase(expressao)
    if not consulta.strip():
        raise ValueError("informe uma palavra, expressão ou referência")
    if not 1 <= limite <= 10000:
        raise ValueError("--limite deve estar entre 1 e 10000")
    if bool(inicio) != bool(fim):
        raise ValueError("informe --de e --ate juntos")
    carregar()
    biblioteca = not inicio
    catalogo = carregar_js(LEITOR / "catalogo-motor.js")
    entradas = sorted({e["testemunho"] for e in catalogo["chaves"].values()}) if biblioteca else periodo(inicio, fim)
    cache, vistos, encontrados = {}, set(), []
    for p in planos(entradas):
        chave = (p["formulario"], p.get("complemento_de"), bool(p.get("missas_noturnas")))
        if biblioteca and chave in vistos:
            continue
        vistos.add(chave)
        if chave not in cache:
            d = documento(None, p)
            complemento = not bool(d["secoes"])
            secs = d["secoes"] or d["complemento_editorial"]["secoes"]
            cache[chave] = [
                {"tipo":s["tipo"], "relativa_a":s.get("relativa_a", ""), "titulo":s["titulo"],
                 "referencia":s["referencia_busca"], "trecho":s["texto"][:240],
                 "origem_texto":"complemento-editorial" if complemento else "cnbb"}
                for s in secs if (not tipos or s["tipo"] in tipos or s.get("relativa_a") in tipos)
                and consulta in frase(" ".join((s["titulo"], s["referencia_busca"], s["texto"])))
            ]
        cab = " ".join([p["celebracao"], p["contexto"], *(o["nome"] for o in p["opcoes_memoria"])])
        por_calendario = not biblioteca and not tipos and consulta in frase(cab)
        if cache[chave] or por_calendario:
            item = {"chave":p["chave"], "celebracao":p["celebracao"],
                    "ocorrencias":cache[chave], "coincide_calendario":por_calendario,
                    "consultar":["dia", p["data"]]}
            if biblioteca:
                item["data_exemplo"] = p["data"]
            else:
                item["data"] = p["data"]
            encontrados.append(item)
            if len(encontrados) > limite:
                break
    return {"schema":"liturgia-busca/v1", "escopo":"biblioteca-de-textos" if biblioteca else "calendario-calculado",
            "expressao":expressao, "inicio":inicio, "fim":fim,
            "limite":limite, "mais_resultados":len(encontrados) > limite, "resultados":encontrados[:limite]}
