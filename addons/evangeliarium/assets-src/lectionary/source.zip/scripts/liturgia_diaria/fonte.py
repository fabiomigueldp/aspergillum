from pathlib import Path

from datetime import timedelta

import hashlib

RAIZ = Path(__file__).resolve().parents[2]

ACERVO = RAIZ / "sources" / "liturgia_diaria" / "cnbb"

API = "https://api-liturgia.edicoescnbb.com.br/contents/in/date/"

def digest(data):
    return hashlib.sha256(data).hexdigest()

def dias(inicio, fim):
    while inicio <= fim:
        yield inicio
        if inicio == fim:
            break
        inicio += timedelta(days=1)
