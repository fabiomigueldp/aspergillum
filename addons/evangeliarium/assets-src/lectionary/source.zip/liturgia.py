from pathlib import Path
import runpy
import sys

scripts = Path(__file__).resolve().parent / "scripts" / "liturgia_diaria"
sys.path.insert(0, str(scripts))
runpy.run_path(str(scripts / "liturgia.py"), run_name="__main__")
